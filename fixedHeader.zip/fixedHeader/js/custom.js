$(function(){
	var nav = $("nav").offset().top;

	$(window).scroll(function(){
		var topDist = $(window).scrollTop();
		
		if(topDist >= nav){
			$("nav").addClass("fixed-header");
		}else{
			$("nav").removeClass("fixed-header");
		}
	});
});